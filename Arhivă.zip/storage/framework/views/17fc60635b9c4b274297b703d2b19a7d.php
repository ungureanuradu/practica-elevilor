<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.bunny.net">
  <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

  <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>

  
  <?php
    $footer = config('footer');
    foreach ($footer['columns'] as &$col) {
      foreach ($col['links'] as &$link) {
        if (!($link['external'] ?? false)) {
          $link['url'] = url($link['url']); // ex: '/istoric' -> 'http://127.0.0.1:8000/istoric'
        }
      }
    }
  ?>
  <script>
    window.footerData = <?php echo json_encode($footer, 15, 512) ?>;
  </script>

  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]); ?>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>
<body class="font-sans antialiased">
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
</body>
</html>
<?php /**PATH /home/radu/Descărcări/proiectelaravel/practica-elevilor/resources/views/app.blade.php ENDPATH**/ ?>